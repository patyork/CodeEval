.. Webscraping documentation master file, created by
   sphinx-quickstart on Fri Dec 28 09:34:47 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

webscraping documentation
=======================================

.. toctree::
   
    introduction
    examples
    reference
    
