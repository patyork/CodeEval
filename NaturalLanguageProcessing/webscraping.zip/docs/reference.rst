.. Webscraping documentation master file, created by
   sphinx-quickstart on Fri Dec 28 09:34:47 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Reference
=======================================


:mod:`adt` Module
-----------------
.. automodule:: webscraping.adt
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`alg` Module
-----------------
.. automodule:: webscraping.alg
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`common` Module
--------------------
.. automodule:: webscraping.common
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`download` Module
----------------------
.. automodule:: webscraping.download
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pdict` Module
-------------------
.. automodule:: webscraping.pdict
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`webkit` Module
--------------------
.. automodule:: webscraping.webkit
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`xpath` Module
-------------------
.. automodule:: webscraping.xpath
    :members:
    :undoc-members:
    :show-inheritance:
