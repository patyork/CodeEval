See here for more info:
http://code.google.com/p/webscraping/
